import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom'
import { GoogleOAuthProvider } from '@react-oauth/google'
import App from './App'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Register from './pages/Register'
import Lobby from './pages/Lobby'
import Room from './pages/Room'
import Leaderboard from './pages/Leaderboard'
import AdminDashboard from './pages/admin/AdminDashboard'
import ProtectedRoute from './components/ProtectedRoute'
import AdminProtectedRoute from './components/AdminProtectedRoute'
import { AuthProvider } from './context/AuthContext'
import './index.css'

const router = createBrowserRouter([
  {
    path: '/welcome',
    element: <Landing />
  },
  {
    path: '/',
    element: <App />,
    children: [
      { 
        index: true,
        element: <Navigate to="/welcome" replace />
      },
      { 
        path: 'lobby', 
        element: (
          <ProtectedRoute>
            <Lobby />
          </ProtectedRoute>
        ) 
      },
      { path: 'login', element: <Login /> },
      { path: 'register', element: <Register /> },
      { 
        path: 'room/:code', 
        element: (
          <ProtectedRoute>
            <Room />
          </ProtectedRoute>
        ) 
      },
      { 
        path: 'leaderboard', 
        element: (
          <ProtectedRoute>
            <Leaderboard />
          </ProtectedRoute>
        ) 
      },
      {
        path: 'admin',
        element: (
          <AdminProtectedRoute>
            <AdminDashboard />
          </AdminProtectedRoute>
        )
      }
    ]
  }
])

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || ''

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
      <AuthProvider>
        <RouterProvider router={router} />
      </AuthProvider>
    </GoogleOAuthProvider>
  </React.StrictMode>
)
