import { Link, Outlet } from 'react-router-dom'
import { useAuth } from './context/AuthContext'

export default function App() {
  const { user, logout, isAdmin } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b shadow-sm">
        <div className="container-app flex items-center justify-between h-16 px-4">
          <Link to="/" className="text-xl font-bold text-brand-700 hover:text-brand-800 transition-colors">
            CodeBattle Arena
          </Link>
          <nav className="flex items-center gap-6">
            {user && (
              <div className="flex items-center gap-4 text-sm font-medium">
                <Link className="text-gray-700 hover:text-brand-700 px-3 py-2 rounded-md hover:bg-gray-100 transition-colors" to="/lobby">
                  Lobby
                </Link>
                <Link className="text-gray-700 hover:text-brand-700 px-3 py-2 rounded-md hover:bg-gray-100 transition-colors" to="/leaderboard">
                  Leaderboard
                </Link>
                {isAdmin && (
                  <Link className="text-red-700 hover:text-red-800 px-3 py-2 rounded-md hover:bg-red-50 transition-colors flex items-center gap-1 font-semibold" to="/admin">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    Admin Panel
                  </Link>
                )}
              </div>
            )}
            <div className="flex items-center gap-3 border-l border-gray-200 pl-6">
              {user ? (
                <>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center">
                      <span className="text-brand-700 font-semibold text-sm">
                        {user.displayName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span className="text-gray-700 font-medium">
                      {user.displayName}
                    </span>
                  </div>
                  <button 
                    className="text-gray-500 hover:text-red-600 px-3 py-2 rounded-md hover:bg-red-50 transition-colors font-medium text-sm" 
                    onClick={logout}
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link className="text-gray-700 hover:text-brand-700 px-4 py-2 rounded-md hover:bg-gray-100 transition-colors font-medium" to="/login">
                    Login
                  </Link>
                  <Link className="bg-brand-600 text-white hover:bg-brand-700 px-4 py-2 rounded-md transition-colors font-medium" to="/register">
                    Register
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      </header>
      <main className="container-app py-8">
        <Outlet />
      </main>
    </div>
  )
}
