export default function Leaderboard() {
  return (
    <div>
      <h2>Leaderboard</h2>
      <p>Coming soon...</p>
    </div>
  )
}
