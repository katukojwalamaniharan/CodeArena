import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import Editor from '@monaco-editor/react'
import Split from 'react-split'
import { Problem } from '../types/problem'
import { getRandomProblem } from '../data/problems'
import api from '../api/client'
import { executeCode } from '../utils/codeExecutor'

export default function Room() {
  const { code: roomCode } = useParams()
  const [problem, setProblem] = useState<Problem | null>(null)
  const [selectedLanguage, setSelectedLanguage] = useState(0)
  const [editorCode, setEditorCode] = useState('')
  const [output, setOutput] = useState('')
  const [isRunning, setIsRunning] = useState(false)
  const [activeTab, setActiveTab] = useState<'description' | 'submissions'>('description')
  const [theme, setTheme] = useState<'vs-dark' | 'light'>('vs-dark')

  useEffect(() => {
    // Load random problem when room is created
    const randomProblem = getRandomProblem()
    setProblem(randomProblem)
    if (randomProblem.codeTemplates.length > 0) {
      setEditorCode(randomProblem.codeTemplates[0].starterCode)
    }
  }, [roomCode])

  const handleLanguageChange = (index: number) => {
    setSelectedLanguage(index)
    if (problem) {
      setEditorCode(problem.codeTemplates[index].starterCode)
    }
  }

  const handleRunCode = async () => {
    if (!problem) return
    setIsRunning(true)
    
    // Get only visible test cases for "Run Code"
    const visibleTestCases = problem.testCases.filter(tc => !tc.isHidden)
    const testCase = visibleTestCases[0]
    
    setOutput(`Running code...\n\nTest Case:\nInput: ${testCase.input}\n\n`)
    
    try {
      // Try backend first
      const response = await api.post('/execute', {
        code: editorCode,
        languageId: problem.codeTemplates[selectedLanguage].languageId,
        testCase: testCase.input
      })
      
      const result = response.data
      let outputText = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
      outputText += `Test Case:\n`
      outputText += `Input: ${testCase.input}\n`
      outputText += `Expected: ${testCase.expectedOutput}\n`
      outputText += `\n`
      
      if (result.status === 'Accepted') {
        outputText += `✓ Status: ${result.status}\n`
        outputText += `Runtime: ${result.time}s | Memory: ${result.memory}KB\n`
        outputText += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
        outputText += `Your Output:\n${result.output || 'No output'}`
      } else {
        outputText += `✗ Status: ${result.status}\n`
        outputText += `\n${result.error || result.statusDescription || 'Execution failed'}\n`
        if (result.output) {
          outputText += `\nYour Output:\n${result.output}`
        }
      }
      
      setOutput(outputText)
    } catch (err: any) {
      // If backend fails, use client-side executor
      if (err.response?.status === 404 || err.code === 'ERR_NETWORK') {
        
        try {
          const result = await executeCode(
            problem.codeTemplates[selectedLanguage].languageId,
            problem.codeTemplates[selectedLanguage].languageName,
            editorCode,
            testCase.input
          )
          
          let outputText = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
          outputText += `Test Case:\n`
          outputText += `Input: ${testCase.input}\n`
          outputText += `Expected: ${testCase.expectedOutput}\n`
          outputText += `\n`
          
          if (result.status === 'Accepted') {
            outputText += `✓ Status: ${result.status} (Client-side)\n`
            outputText += `Runtime: ${result.time.toFixed(3)}s\n`
            outputText += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
            outputText += `Your Output:\n${result.output}`
          } else {
            outputText += `✗ Status: ${result.status}\n`
            outputText += `\n${result.error || 'Execution failed'}\n`
            if (result.output) {
              outputText += `\nYour Output:\n${result.output}`
            }
          }
          setOutput(outputText)
        } catch (clientErr: any) {
          setOutput(`✗ Client-side execution failed:\n${clientErr.message}`)
        }
      } else {
        const errorMsg = err.response?.data?.message || err.message || 'Failed to execute code'
        setOutput(`✗ Error: ${errorMsg}\n\nPlease check your code and try again.`)
      }
    } finally {
      setIsRunning(false)
    }
  }

  const handleSubmit = async () => {
    if (!problem) return
    setIsRunning(true)
    setOutput(`Submitting code...\nRunning ${problem.testCases.length} test cases (including hidden tests)...\n\n`)
    
    try {
      const response = await api.post('/submit', {
        code: editorCode,
        languageId: problem.codeTemplates[selectedLanguage].languageId,
        problemId: problem.id
      })
      
      const result = response.data
      let outputText = ''
      
      if (result.status === 'Accepted') {
        outputText += `✓✓✓ ACCEPTED ✓✓✓\n\n`
        outputText += `All test cases passed: ${result.testsPassed}/${result.testsTotal}\n`
      } else {
        outputText += `✗ ${result.status}\n\n`
        outputText += `Test cases passed: ${result.testsPassed}/${result.testsTotal}\n`
      }
      
      outputText += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
      outputText += `Detailed Test Results:\n\n`
      
      if (result.details && result.details.length > 0) {
        result.details.forEach((test: any, idx: number) => {
          const testCase = problem.testCases[idx]
          const isHidden = testCase?.isHidden
          
          outputText += `Test Case ${idx + 1}${isHidden ? ' (Hidden)' : ''}: ${test.passed ? '✓ PASS' : '✗ FAIL'}\n`
          if (!test.passed) {
            if (!isHidden && test.input) outputText += `  Input: ${test.input}\n`
            if (!isHidden && test.expectedOutput) outputText += `  Expected: ${test.expectedOutput}\n`
            if (test.actualOutput) outputText += `  Your Output: ${test.actualOutput}\n`
            if (test.error) outputText += `  Error: ${test.error}\n`
          }
          outputText += `\n`
        })
      }
      
      setOutput(outputText)
    } catch (err: any) {
      // Fallback to client-side testing against all test cases
      if (err.response?.status === 404 || err.code === 'ERR_NETWORK') {
        try {
          let passed = 0
          let total = problem.testCases.length
          let results: string[] = []
          
          for (let i = 0; i < problem.testCases.length; i++) {
            const testCase = problem.testCases[i]
            const result = await executeCode(
              problem.codeTemplates[selectedLanguage].languageId,
              problem.codeTemplates[selectedLanguage].languageName,
              editorCode,
              testCase.input
            )
            
            const testPassed = result.output.trim() === testCase.expectedOutput.trim()
            if (testPassed) passed++
            
            let testResult = `Test Case ${i + 1}${testCase.isHidden ? ' (Hidden)' : ''}: ${testPassed ? '✓ PASS' : '✗ FAIL'}\n`
            if (!testPassed) {
              if (!testCase.isHidden) testResult += `  Input: ${testCase.input}\n`
              if (!testCase.isHidden) testResult += `  Expected: ${testCase.expectedOutput}\n`
              testResult += `  Your Output: ${result.output.trim()}\n`
            }
            results.push(testResult)
          }
          
          let outputText = ''
          if (passed === total) {
            outputText += `✓✓✓ ACCEPTED ✓✓✓\n\n`
          } else {
            outputText += `✗ WRONG ANSWER\n\n`
          }
          
          outputText += `Test cases passed: ${passed}/${total}\n`
          outputText += `(Client-side testing)\n`
          outputText += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
          outputText += `Detailed Test Results:\n\n`
          outputText += results.join('\n')
          
          setOutput(outputText)
        } catch (clientErr: any) {
          setOutput(`✗ Submission Error: ${clientErr.message}`)
        }
      } else {
        const errorMsg = err.response?.data?.message || err.message || 'Failed to submit code'
        setOutput(`✗ Submission Error: ${errorMsg}\n\nPlease check your code and try again.`)
      }
    } finally {
      setIsRunning(false)
    }
  }

  if (!problem) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-gray-600">Loading problem...</div>
      </div>
    )
  }

  const currentLanguage = problem.codeTemplates[selectedLanguage]

  return (
    <div className="fixed inset-0 top-16 bg-dark">
      <Split
        className="flex h-full"
        sizes={[50, 50]}
        minSize={300}
        gutterSize={8}
        gutterStyle={() => ({
          backgroundColor: '#1e1e1e',
          cursor: 'col-resize'
        })}
      >
        {/* Left Panel - Problem Description */}
        <div className="bg-white overflow-y-auto">
          <div className="sticky top-0 bg-white border-b z-10">
            <div className="flex items-center gap-4 px-6 py-3">
              <button
                className={`pb-2 px-1 font-medium text-sm ${
                  activeTab === 'description'
                    ? 'text-gray-900 border-b-2 border-blue-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                onClick={() => setActiveTab('description')}
              >
                Description
              </button>
              <button
                className={`pb-2 px-1 font-medium text-sm ${
                  activeTab === 'submissions'
                    ? 'text-gray-900 border-b-2 border-blue-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                onClick={() => setActiveTab('submissions')}
              >
                Submissions
              </button>
            </div>
          </div>

          <div className="px-6 py-4">
            {activeTab === 'description' && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-2xl font-semibold text-gray-900 mb-2">
                    {problem.id}. {problem.title}
                  </h1>
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                      problem.difficulty === 'Easy'
                        ? 'bg-green-100 text-green-800'
                        : problem.difficulty === 'Medium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {problem.difficulty}
                  </span>
                </div>

                <div className="prose prose-sm max-w-none">
                  <p className="text-gray-700 whitespace-pre-line">{problem.description}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Examples:</h3>
                  {problem.examples.map((example, idx) => (
                    <div key={idx} className="mb-4 bg-gray-50 rounded-lg p-4">
                      <div className="font-medium text-sm text-gray-700 mb-1">
                        Example {idx + 1}:
                      </div>
                      <div className="space-y-1 text-sm">
                        <div>
                          <span className="font-semibold">Input:</span> {example.input}
                        </div>
                        <div>
                          <span className="font-semibold">Output:</span> {example.output}
                        </div>
                        {example.explanation && (
                          <div>
                            <span className="font-semibold">Explanation:</span> {example.explanation}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Constraints:</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {problem.constraints.map((constraint, idx) => (
                      <li key={idx}>{constraint}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {activeTab === 'submissions' && (
              <div className="text-center py-12 text-gray-500">
                <p>Your submissions will appear here</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Panel - Code Editor */}
        <div className="flex flex-col bg-[#1e1e1e]">
          {/* Editor Header */}
          <div className="flex items-center justify-between px-4 py-2 bg-[#2d2d30] border-b border-gray-700">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd"/>
                </svg>
                <div className="relative">
                  <select
                    value={selectedLanguage}
                    onChange={(e) => handleLanguageChange(Number(e.target.value))}
                    className="appearance-none bg-[#3c3c3c] text-white text-sm font-medium px-4 py-2 pr-10 rounded-lg border border-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-[#4a4a4c] transition-all cursor-pointer"
                  >
                    {problem.codeTemplates.map((template, idx) => (
                      <option key={idx} value={idx} className="bg-[#2d2d30]">
                        {template.languageName}
                      </option>
                    ))}
                  </select>
                  <svg className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
              
              <button
                onClick={() => setTheme(theme === 'vs-dark' ? 'light' : 'vs-dark')}
                className="flex items-center gap-2 bg-[#3c3c3c] text-gray-300 text-sm px-4 py-2 rounded-lg border border-gray-600 hover:bg-[#4c4c4c] hover:border-gray-500 transition-all shadow-sm"
                title={`Switch to ${theme === 'vs-dark' ? 'Light' : 'Dark'} theme`}
              >
                {theme === 'vs-dark' ? (
                  <>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z"/>
                    </svg>
                    <span className="font-medium">Light</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"/>
                    </svg>
                    <span className="font-medium">Dark</span>
                  </>
                )}
              </button>
            </div>
            <div className="text-gray-400 text-xs font-mono">
              Room: <span className="text-blue-400 font-semibold">{roomCode}</span>
            </div>
          </div>

          {/* Monaco Editor */}
          <div className="flex-1 overflow-hidden">
            <Editor
              height="100%"
              language={currentLanguage.languageName.toLowerCase()}
              value={editorCode}
              onChange={(value) => setEditorCode(value || '')}
              theme={theme}
              options={{
                fontSize: 14,
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                automaticLayout: true,
                tabSize: 4,
                wordWrap: 'on',
                lineNumbers: 'on',
                roundedSelection: true,
                cursorStyle: 'line',
                formatOnPaste: true,
                formatOnType: true
              }}
            />
          </div>

          {/* Output Console */}
          <div className="h-48 border-t border-gray-700 bg-[#1e1e1e] flex flex-col">
            <div className="flex items-center justify-between px-4 py-2 bg-[#2d2d30] border-b border-gray-700">
              <span className="text-gray-300 text-sm font-medium">Output</span>
              <button
                onClick={() => setOutput('')}
                className="text-gray-400 hover:text-white text-xs"
              >
                Clear
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <pre className="text-gray-300 text-sm font-mono whitespace-pre-wrap">
                {output || 'Run your code to see output here...'}
              </pre>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 px-4 py-3 bg-[#2d2d30] border-t border-gray-700">
            <button
              onClick={handleRunCode}
              disabled={isRunning}
              className="px-6 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded font-medium text-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isRunning ? 'Running...' : 'Run Code'}
            </button>
            <button
              onClick={handleSubmit}
              disabled={isRunning}
              className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded font-medium text-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isRunning ? 'Submitting...' : 'Submit'}
            </button>
          </div>
        </div>
      </Split>
    </div>
  )
}
