import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { GoogleLogin, CredentialResponse } from '@react-oauth/google'
import api from '../api/client'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()
  const { login } = useAuth()

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    try {
      const res = await api.post('/auth/login', { email, password })
      console.log('Login response:', res.data)
      const { token, userId, displayName, email: em } = res.data
      console.log('Calling login with:', { token, userId, displayName, email: em })
      login(token, { userId, displayName, email: em })
      console.log('Login successful, navigating to /lobby')
      navigate('/lobby')
    } catch (err: any) {
      console.error('Login error:', err)
      setError(err?.response?.data?.error ?? 'Login failed')
    }
  }

  const onGoogleSuccess = async (credentialResponse: CredentialResponse) => {
    setError(null)
    try {
      const res = await api.post('/auth/google', { idToken: credentialResponse.credential })
      const { token, userId, displayName, email: em } = res.data
      login(token, { userId, displayName, email: em })
      navigate('/lobby')
    } catch (err: any) {
      setError(err?.response?.data?.error ?? 'Google login failed')
    }
  }

  const onGoogleError = () => {
    setError('Google login failed. Please try again.')
  }

  return (
    <div className="max-w-md mx-auto">
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Welcome back</h2>
        {error && <div className="mb-3 text-sm text-red-600">{error}</div>}
        <form onSubmit={onSubmit} className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input className="input mt-1" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Password</label>
            <input className="input mt-1" placeholder="••••••••" type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <div className="pt-2">
            <button className="btn w-full" type="submit">Sign in</button>
          </div>
        </form>
        
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">Or continue with</span>
            </div>
          </div>
          
          <div className="mt-4 flex justify-center">
            <GoogleLogin
              onSuccess={onGoogleSuccess}
              onError={onGoogleError}
              useOneTap
              theme="outline"
              size="large"
              width="384"
            />
          </div>
        </div>
        
        <p className="mt-4 text-sm text-gray-600">No account? <a className="text-brand-700 hover:underline" href="/register">Register</a></p>
      </div>
    </div>
  )
}
