import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Lobby() {
  const navigate = useNavigate()

  const createRoom = () => {
    const code = Math.random().toString(36).slice(2, 7).toUpperCase()
    navigate(`/room/${code}`)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">Lobby</h2>
          <p className="text-gray-600">Create a room or join with a code to battle in real time.</p>
        </div>
        <button className="btn" onClick={createRoom}>Create Room</button>
      </div>
      <JoinForm />
    </div>
  )
}

function JoinForm() {
  const navigate = useNavigate()
  const [code, setCode] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    
    if (!code.trim()) {
      setError('Please enter a room code')
      return
    }
    
    if (code.trim().length < 3) {
      setError('Room code must be at least 3 characters')
      return
    }
    
    navigate(`/room/${code.trim().toUpperCase()}`)
  }

  return (
    <div className="card max-w-md">
      <h3 className="text-lg font-semibold mb-4">Join Existing Room</h3>
      {error && (
        <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}
      <form className="space-y-3" onSubmit={handleSubmit}>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Room code</label>
          <input 
            className="input mt-1" 
            placeholder="Enter room code (e.g., ABCDE)" 
            value={code}
            onChange={(e) => setCode(e.target.value)}
            maxLength={10}
          />
        </div>
        <div>
          <button className="btn w-full" type="submit">Join Room</button>
        </div>
      </form>
    </div>
  )
}
