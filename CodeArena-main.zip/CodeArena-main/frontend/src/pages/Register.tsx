import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../api/client'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()
  const { login } = useAuth()

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    try {
      const res = await api.post('/auth/register', { email, password, displayName })
      const { token, userId, displayName: dn, email: em } = res.data
      login(token, { userId, displayName: dn, email: em })
      navigate('/lobby')
    } catch (err: any) {
      setError(err?.response?.data?.error ?? 'Registration failed')
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Create your account</h2>
        {error && <div className="mb-3 text-sm text-red-600">{error}</div>}
        <form onSubmit={onSubmit} className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Display name</label>
            <input className="input mt-1" placeholder="Player One" value={displayName} onChange={e => setDisplayName(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input className="input mt-1" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Password</label>
            <input className="input mt-1" placeholder="••••••••" type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <div className="pt-2">
            <button className="btn w-full" type="submit">Create account</button>
          </div>
        </form>
        <p className="mt-4 text-sm text-gray-600">Already have an account? <a className="text-brand-700 hover:underline" href="/login">Sign in</a></p>
      </div>
    </div>
  )
}
