import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'

export type AuthUser = {
  userId: number
  displayName: string
  email: string
}

type AuthContextType = {
  user: AuthUser | null
  token: string | null
  isAdmin: boolean
  login: (token: string, user: AuthUser) => void
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null)
  const [user, setUser] = useState<AuthUser | null>(null)

  // Check if user is admin
  const isAdmin = user?.email?.toLowerCase() === 'krupakargurija177@gmail.com'

  useEffect(() => {
    const t = localStorage.getItem('cba_token')
    const u = localStorage.getItem('cba_user')
    if (t) setToken(t)
    if (u) setUser(JSON.parse(u))
  }, [])

  const login = (t: string, u: AuthUser) => {
    console.log('AuthContext login called with:', { token: t, user: u })
    setToken(t)
    setUser(u)
    localStorage.setItem('cba_token', t)
    localStorage.setItem('cba_user', JSON.stringify(u))
    console.log('AuthContext login completed, user state updated')
  }

  const logout = () => {
    setToken(null)
    setUser(null)
    localStorage.removeItem('cba_token')
    localStorage.removeItem('cba_user')
  }

  const value = useMemo(() => ({ user, token, isAdmin, login, logout }), [user, token, isAdmin])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
