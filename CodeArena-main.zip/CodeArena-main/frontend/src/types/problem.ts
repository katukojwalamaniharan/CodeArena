export type Difficulty = 'Easy' | 'Medium' | 'Hard'

export type TestCase = {
  input: string
  expectedOutput: string
  isHidden?: boolean
}

export type CodeTemplate = {
  languageId: number
  languageName: string
  starterCode: string
}

export type Problem = {
  id: number
  title: string
  difficulty: Difficulty
  description: string
  examples: {
    input: string
    output: string
    explanation?: string
  }[]
  constraints: string[]
  testCases: TestCase[]
  codeTemplates: CodeTemplate[]
  timeLimit: number // in seconds
  memoryLimit: number // in MB
}
