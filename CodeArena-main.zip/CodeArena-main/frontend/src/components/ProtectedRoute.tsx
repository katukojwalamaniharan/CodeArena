import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

interface ProtectedRouteProps {
  children: React.ReactNode
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, token } = useAuth()

  // If no user or token, redirect to landing page
  if (!user || !token) {
    return <Navigate to="/welcome" replace />
  }

  return <>{children}</>
}
