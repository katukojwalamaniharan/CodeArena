import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

interface AdminProtectedRouteProps {
  children: React.ReactNode
}

export default function AdminProtectedRoute({ children }: AdminProtectedRouteProps) {
  const { user, isAdmin } = useAuth()

  // If not logged in, redirect to login
  if (!user) {
    return <Navigate to="/login" replace />
  }

  // If logged in but not admin, redirect to lobby
  if (!isAdmin) {
    return <Navigate to="/lobby" replace />
  }

  return <>{children}</>
}
