import { Problem } from '../types/problem'

export const PROBLEMS: Problem[] = [
  {
    id: 1,
    title: 'Two Sum',
    difficulty: 'Easy',
    description: `Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

You may assume that each input would have exactly one solution, and you may not use the same element twice.

You can return the answer in any order.`,
    examples: [
      {
        input: 'nums = [2,7,11,15], target = 9',
        output: '[0,1]',
        explanation: 'Because nums[0] + nums[1] == 9, we return [0, 1].'
      },
      {
        input: 'nums = [3,2,4], target = 6',
        output: '[1,2]'
      },
      {
        input: 'nums = [3,3], target = 6',
        output: '[0,1]'
      }
    ],
    constraints: [
      '2 <= nums.length <= 10^4',
      '-10^9 <= nums[i] <= 10^9',
      '-10^9 <= target <= 10^9',
      'Only one valid answer exists.'
    ],
    testCases: [
      { input: '[2,7,11,15]\n9', expectedOutput: '[0,1]' },
      { input: '[3,2,4]\n6', expectedOutput: '[1,2]' },
      { input: '[3,3]\n6', expectedOutput: '[0,1]' },
      { input: '[1,5,3,7,9]\n12', expectedOutput: '[2,4]', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def twoSum(nums, target):
    # Write your code here
    pass

# Test
nums = list(map(int, input().split()))
target = int(input())
result = twoSum(nums, target)
print(result)`
      },
      {
        languageId: 62,
        languageName: 'Java',
        starterCode: `import java.util.*;

class Solution {
    public int[] twoSum(int[] nums, int target) {
        // Write your code here
        return new int[]{};
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] input = sc.nextLine().split(" ");
        int[] nums = new int[input.length];
        for (int i = 0; i < input.length; i++) {
            nums[i] = Integer.parseInt(input[i]);
        }
        int target = sc.nextInt();
        
        Solution sol = new Solution();
        int[] result = sol.twoSum(nums, target);
        System.out.println(Arrays.toString(result));
    }
}`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function twoSum(nums, target) {
    // Write your code here
}

// Test
const input = require('fs').readFileSync(0, 'utf-8').trim().split('\\n');
const nums = input[0].split(' ').map(Number);
const target = parseInt(input[1]);
const result = twoSum(nums, target);
console.log(JSON.stringify(result));`
      },
      {
        languageId: 54,
        languageName: 'C++',
        starterCode: `#include <iostream>
#include <vector>
#include <sstream>
using namespace std;

vector<int> twoSum(vector<int>& nums, int target) {
    // Write your code here
    return {};
}

int main() {
    string line;
    getline(cin, line);
    istringstream iss(line);
    vector<int> nums;
    int num;
    while (iss >> num) nums.push_back(num);
    
    int target;
    cin >> target;
    
    vector<int> result = twoSum(nums, target);
    cout << "[" << result[0] << "," << result[1] << "]" << endl;
    return 0;
}`
      }
    ],
    timeLimit: 2,
    memoryLimit: 256
  },
  {
    id: 2,
    title: 'Reverse String',
    difficulty: 'Easy',
    description: `Write a function that reverses a string. The input string is given as an array of characters s.

You must do this by modifying the input array in-place with O(1) extra memory.`,
    examples: [
      {
        input: 's = ["h","e","l","l","o"]',
        output: '["o","l","l","e","h"]'
      },
      {
        input: 's = ["H","a","n","n","a","h"]',
        output: '["h","a","n","n","a","H"]'
      }
    ],
    constraints: [
      '1 <= s.length <= 10^5',
      's[i] is a printable ascii character.'
    ],
    testCases: [
      { input: 'hello', expectedOutput: 'olleh' },
      { input: 'Hannah', expectedOutput: 'hannaH' },
      { input: 'a', expectedOutput: 'a' },
      { input: 'racecar', expectedOutput: 'racecar', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def reverseString(s):
    # Write your code here
    pass

# Test
s = input().strip()
result = reverseString(list(s))
print(''.join(result) if result else '')`
      },
      {
        languageId: 62,
        languageName: 'Java',
        starterCode: `import java.util.*;

class Solution {
    public void reverseString(char[] s) {
        // Write your code here
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        char[] s = input.toCharArray();
        
        Solution sol = new Solution();
        sol.reverseString(s);
        System.out.println(new String(s));
    }
}`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function reverseString(s) {
    // Write your code here
}

// Test
const input = require('fs').readFileSync(0, 'utf-8').trim();
const s = input.split('');
reverseString(s);
console.log(s.join(''));`
      },
      {
        languageId: 54,
        languageName: 'C++',
        starterCode: `#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

void reverseString(string& s) {
    // Write your code here
}

int main() {
    string s;
    getline(cin, s);
    reverseString(s);
    cout << s << endl;
    return 0;
}`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 3,
    title: 'Palindrome Number',
    difficulty: 'Easy',
    description: `Given an integer x, return true if x is a palindrome, and false otherwise.

An integer is a palindrome when it reads the same forward and backward.

For example, 121 is a palindrome while 123 is not.`,
    examples: [
      {
        input: 'x = 121',
        output: 'true',
        explanation: '121 reads as 121 from left to right and from right to left.'
      },
      {
        input: 'x = -121',
        output: 'false',
        explanation: 'From left to right, it reads -121. From right to left, it becomes 121-. Therefore it is not a palindrome.'
      },
      {
        input: 'x = 10',
        output: 'false',
        explanation: 'Reads 01 from right to left. Therefore it is not a palindrome.'
      }
    ],
    constraints: [
      '-2^31 <= x <= 2^31 - 1'
    ],
    testCases: [
      { input: '121', expectedOutput: 'true' },
      { input: '-121', expectedOutput: 'false' },
      { input: '10', expectedOutput: 'false' },
      { input: '12321', expectedOutput: 'true', isHidden: true },
      { input: '0', expectedOutput: 'true', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def isPalindrome(x):
    # Write your code here
    pass

# Test
x = int(input())
result = isPalindrome(x)
print(str(result).lower())`
      },
      {
        languageId: 62,
        languageName: 'Java',
        starterCode: `import java.util.*;

class Solution {
    public boolean isPalindrome(int x) {
        // Write your code here
        return false;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        
        Solution sol = new Solution();
        boolean result = sol.isPalindrome(x);
        System.out.println(result);
    }
}`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function isPalindrome(x) {
    // Write your code here
    return false;
}

// Test
const input = require('fs').readFileSync(0, 'utf-8').trim();
const x = parseInt(input);
const result = isPalindrome(x);
console.log(result);`
      },
      {
        languageId: 54,
        languageName: 'C++',
        starterCode: `#include <iostream>
using namespace std;

bool isPalindrome(int x) {
    // Write your code here
    return false;
}

int main() {
    int x;
    cin >> x;
    bool result = isPalindrome(x);
    cout << (result ? "true" : "false") << endl;
    return 0;
}`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 4,
    title: 'Valid Parentheses',
    difficulty: 'Easy',
    description: `Given a string s containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.

An input string is valid if:
1. Open brackets must be closed by the same type of brackets.
2. Open brackets must be closed in the correct order.
3. Every close bracket has a corresponding open bracket of the same type.`,
    examples: [
      {
        input: 's = "()"',
        output: 'true'
      },
      {
        input: 's = "()[]{}"',
        output: 'true'
      },
      {
        input: 's = "(]"',
        output: 'false'
      }
    ],
    constraints: [
      '1 <= s.length <= 10^4',
      's consists of parentheses only \'()[]{}\'.'
    ],
    testCases: [
      { input: '()', expectedOutput: 'true' },
      { input: '()[]{}', expectedOutput: 'true' },
      { input: '(]', expectedOutput: 'false' },
      { input: '([)]', expectedOutput: 'false', isHidden: true },
      { input: '{[]}', expectedOutput: 'true', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def isValid(s):
    # Write your code here
    pass

# Test
s = input().strip()
result = isValid(s)
print(str(result).lower())`
      },
      {
        languageId: 62,
        languageName: 'Java',
        starterCode: `import java.util.*;

class Solution {
    public boolean isValid(String s) {
        // Write your code here
        return false;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        
        Solution sol = new Solution();
        boolean result = sol.isValid(s);
        System.out.println(result);
    }
}`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function isValid(s) {
    // Write your code here
    return false;
}

// Test
const input = require('fs').readFileSync(0, 'utf-8').trim();
const result = isValid(input);
console.log(result);`
      },
      {
        languageId: 54,
        languageName: 'C++',
        starterCode: `#include <iostream>
#include <string>
using namespace std;

bool isValid(string s) {
    // Write your code here
    return false;
}

int main() {
    string s;
    getline(cin, s);
    bool result = isValid(s);
    cout << (result ? "true" : "false") << endl;
    return 0;
}`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 5,
    title: 'Maximum Subarray',
    difficulty: 'Medium',
    description: `Given an integer array nums, find the subarray with the largest sum, and return its sum.

A subarray is a contiguous non-empty sequence of elements within an array.`,
    examples: [
      {
        input: 'nums = [-2,1,-3,4,-1,2,1,-5,4]',
        output: '6',
        explanation: 'The subarray [4,-1,2,1] has the largest sum 6.'
      },
      {
        input: 'nums = [1]',
        output: '1'
      },
      {
        input: 'nums = [5,4,-1,7,8]',
        output: '23'
      }
    ],
    constraints: [
      '1 <= nums.length <= 10^5',
      '-10^4 <= nums[i] <= 10^4'
    ],
    testCases: [
      { input: '-2 1 -3 4 -1 2 1 -5 4', expectedOutput: '6' },
      { input: '1', expectedOutput: '1' },
      { input: '5 4 -1 7 8', expectedOutput: '23' },
      { input: '-1', expectedOutput: '-1', isHidden: true },
      { input: '-2 -1', expectedOutput: '-1', isHidden: true },
      { input: '1 2 -1 -2 2 1 -2 1', expectedOutput: '3', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def maxSubArray(nums):
    # Write your code here
    pass

# Test
nums = list(map(int, input().split()))
result = maxSubArray(nums)
print(result)`
      },
      {
        languageId: 62,
        languageName: 'Java',
        starterCode: `import java.util.*;

class Solution {
    public int maxSubArray(int[] nums) {
        // Write your code here
        return 0;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] input = sc.nextLine().split(" ");
        int[] nums = new int[input.length];
        for (int i = 0; i < input.length; i++) {
            nums[i] = Integer.parseInt(input[i]);
        }
        
        Solution sol = new Solution();
        int result = sol.maxSubArray(nums);
        System.out.println(result);
    }
}`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function maxSubArray(nums) {
    // Write your code here
    return 0;
}

// Test
const input = require('fs').readFileSync(0, 'utf-8').trim();
const nums = input.split(' ').map(Number);
const result = maxSubArray(nums);
console.log(result);`
      },
      {
        languageId: 54,
        languageName: 'C++',
        starterCode: `#include <iostream>
#include <vector>
#include <sstream>
using namespace std;

int maxSubArray(vector<int>& nums) {
    // Write your code here
    return 0;
}

int main() {
    string line;
    getline(cin, line);
    istringstream iss(line);
    vector<int> nums;
    int num;
    while (iss >> num) nums.push_back(num);
    
    int result = maxSubArray(nums);
    cout << result << endl;
    return 0;
}`
      }
    ],
    timeLimit: 2,
    memoryLimit: 256
  },
  {
    id: 6,
    title: 'Merge Two Sorted Lists',
    difficulty: 'Easy',
    description: `You are given the heads of two sorted linked lists list1 and list2.

Merge the two lists into one sorted list. The list should be made by splicing together the nodes of the first two lists.

Return the head of the merged linked list.`,
    examples: [
      {
        input: 'list1 = [1,2,4], list2 = [1,3,4]',
        output: '[1,1,2,3,4,4]'
      },
      {
        input: 'list1 = [], list2 = []',
        output: '[]'
      },
      {
        input: 'list1 = [], list2 = [0]',
        output: '[0]'
      }
    ],
    constraints: [
      'The number of nodes in both lists is in the range [0, 50].',
      '-100 <= Node.val <= 100',
      'Both list1 and list2 are sorted in non-decreasing order.'
    ],
    testCases: [
      { input: '1 2 4\n1 3 4', expectedOutput: '1 1 2 3 4 4' },
      { input: '\n', expectedOutput: '' },
      { input: '\n0', expectedOutput: '0' },
      { input: '2 3 5\n1 4', expectedOutput: '1 2 3 4 5', isHidden: true },
      { input: '1\n2', expectedOutput: '1 2', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def mergeTwoLists(list1, list2):
    # Write your code here
    # list1 and list2 are lists of integers
    # Return merged list
    pass

# Test
line1 = input().strip()
line2 = input().strip()
list1 = list(map(int, line1.split())) if line1 else []
list2 = list(map(int, line2.split())) if line2 else []
result = mergeTwoLists(list1, list2)
print(' '.join(map(str, result)) if result else '')`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function mergeTwoLists(list1, list2) {
    // Write your code here
    return [];
}

// Test
const lines = require('fs').readFileSync(0, 'utf-8').trim().split('\\n');
const list1 = lines[0] ? lines[0].split(' ').map(Number) : [];
const list2 = lines[1] ? lines[1].split(' ').map(Number) : [];
const result = mergeTwoLists(list1, list2);
console.log(result.join(' '));`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 7,
    title: 'Best Time to Buy and Sell Stock',
    difficulty: 'Easy',
    description: `You are given an array prices where prices[i] is the price of a given stock on the ith day.

You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that stock.

Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.`,
    examples: [
      {
        input: 'prices = [7,1,5,3,6,4]',
        output: '5',
        explanation: 'Buy on day 2 (price = 1) and sell on day 5 (price = 6), profit = 6-1 = 5.'
      },
      {
        input: 'prices = [7,6,4,3,1]',
        output: '0',
        explanation: 'In this case, no transactions are done and the max profit = 0.'
      }
    ],
    constraints: [
      '1 <= prices.length <= 10^5',
      '0 <= prices[i] <= 10^4'
    ],
    testCases: [
      { input: '7 1 5 3 6 4', expectedOutput: '5' },
      { input: '7 6 4 3 1', expectedOutput: '0' },
      { input: '2 4 1', expectedOutput: '2', isHidden: true },
      { input: '3 2 6 5 0 3', expectedOutput: '4', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def maxProfit(prices):
    # Write your code here
    pass

# Test
prices = list(map(int, input().split()))
result = maxProfit(prices)
print(result)`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function maxProfit(prices) {
    // Write your code here
    return 0;
}

// Test
const input = require('fs').readFileSync(0, 'utf-8').trim();
const prices = input.split(' ').map(Number);
const result = maxProfit(prices);
console.log(result);`
      }
    ],
    timeLimit: 2,
    memoryLimit: 256
  },
  {
    id: 8,
    title: 'Contains Duplicate',
    difficulty: 'Easy',
    description: `Given an integer array nums, return true if any value appears at least twice in the array, and return false if every element is distinct.`,
    examples: [
      { input: 'nums = [1,2,3,1]', output: 'true' },
      { input: 'nums = [1,2,3,4]', output: 'false' },
      { input: 'nums = [1,1,1,3,3,4,3,2,4,2]', output: 'true' }
    ],
    constraints: ['1 <= nums.length <= 10^5', '-10^9 <= nums[i] <= 10^9'],
    testCases: [
      { input: '1 2 3 1', expectedOutput: 'true' },
      { input: '1 2 3 4', expectedOutput: 'false' },
      { input: '1 1 1 3 3 4 3 2 4 2', expectedOutput: 'true', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def containsDuplicate(nums):
    pass

nums = list(map(int, input().split()))
print(str(containsDuplicate(nums)).lower())`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function containsDuplicate(nums) {
    return false;
}

const nums = require('fs').readFileSync(0, 'utf-8').trim().split(' ').map(Number);
console.log(containsDuplicate(nums));`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 9,
    title: 'Missing Number',
    difficulty: 'Easy',
    description: `Given an array nums containing n distinct numbers in the range [0, n], return the only number in the range that is missing from the array.`,
    examples: [
      { input: 'nums = [3,0,1]', output: '2' },
      { input: 'nums = [0,1]', output: '2' },
      { input: 'nums = [9,6,4,2,3,5,7,0,1]', output: '8' }
    ],
    constraints: ['n == nums.length', '1 <= n <= 10^4', '0 <= nums[i] <= n'],
    testCases: [
      { input: '3 0 1', expectedOutput: '2' },
      { input: '0 1', expectedOutput: '2' },
      { input: '9 6 4 2 3 5 7 0 1', expectedOutput: '8', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def missingNumber(nums):
    pass

nums = list(map(int, input().split()))
print(missingNumber(nums))`
      },
      {
        languageId: 63,
        languageName: 'JavaScript',
        starterCode: `function missingNumber(nums) {
    return 0;
}

const nums = require('fs').readFileSync(0, 'utf-8').trim().split(' ').map(Number);
console.log(missingNumber(nums));`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 10,
    title: 'Single Number',
    difficulty: 'Easy',
    description: `Given a non-empty array of integers nums, every element appears twice except for one. Find that single one.`,
    examples: [
      { input: 'nums = [2,2,1]', output: '1' },
      { input: 'nums = [4,1,2,1,2]', output: '4' },
      { input: 'nums = [1]', output: '1' }
    ],
    constraints: ['1 <= nums.length <= 3 * 10^4', '-3 * 10^4 <= nums[i] <= 3 * 10^4'],
    testCases: [
      { input: '2 2 1', expectedOutput: '1' },
      { input: '4 1 2 1 2', expectedOutput: '4' },
      { input: '1', expectedOutput: '1', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def singleNumber(nums):
    pass

nums = list(map(int, input().split()))
print(singleNumber(nums))`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 11,
    title: 'Move Zeroes',
    difficulty: 'Easy',
    description: `Given an integer array nums, move all 0's to the end of it while maintaining the relative order of the non-zero elements.`,
    examples: [
      { input: 'nums = [0,1,0,3,12]', output: '[1,3,12,0,0]' }
    ],
    constraints: ['1 <= nums.length <= 10^4', '-2^31 <= nums[i] <= 2^31 - 1'],
    testCases: [
      { input: '0 1 0 3 12', expectedOutput: '1 3 12 0 0' },
      { input: '0', expectedOutput: '0', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def moveZeroes(nums):
    pass
    return nums

nums = list(map(int, input().split()))
result = moveZeroes(nums)
print(' '.join(map(str, result)))`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 12,
    title: 'Fizz Buzz',
    difficulty: 'Easy',
    description: `Given an integer n, return a string array answer (1-indexed) where:
- answer[i] == "FizzBuzz" if i is divisible by 3 and 5.
- answer[i] == "Fizz" if i is divisible by 3.
- answer[i] == "Buzz" if i is divisible by 5.
- answer[i] == i (as a string) if none of the above conditions are true.`,
    examples: [
      { input: 'n = 3', output: '["1","2","Fizz"]' },
      { input: 'n = 5', output: '["1","2","Fizz","4","Buzz"]' },
      { input: 'n = 15', output: '["1","2","Fizz","4","Buzz","Fizz","7","8","Fizz","Buzz","11","Fizz","13","14","FizzBuzz"]' }
    ],
    constraints: ['1 <= n <= 10^4'],
    testCases: [
      { input: '3', expectedOutput: '1 2 Fizz' },
      { input: '5', expectedOutput: '1 2 Fizz 4 Buzz' },
      { input: '15', expectedOutput: '1 2 Fizz 4 Buzz Fizz 7 8 Fizz Buzz 11 Fizz 13 14 FizzBuzz', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def fizzBuzz(n):
    pass

n = int(input())
result = fizzBuzz(n)
print(' '.join(result))`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 13,
    title: 'Power of Two',
    difficulty: 'Easy',
    description: `Given an integer n, return true if it is a power of two. Otherwise, return false.`,
    examples: [
      { input: 'n = 1', output: 'true', explanation: '2^0 = 1' },
      { input: 'n = 16', output: 'true', explanation: '2^4 = 16' },
      { input: 'n = 3', output: 'false' }
    ],
    constraints: ['-2^31 <= n <= 2^31 - 1'],
    testCases: [
      { input: '1', expectedOutput: 'true' },
      { input: '16', expectedOutput: 'true' },
      { input: '3', expectedOutput: 'false', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def isPowerOfTwo(n):
    pass

n = int(input())
print(str(isPowerOfTwo(n)).lower())`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 14,
    title: 'Climbing Stairs',
    difficulty: 'Easy',
    description: `You are climbing a staircase. It takes n steps to reach the top. Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?`,
    examples: [
      { input: 'n = 2', output: '2', explanation: '1. 1 step + 1 step\n2. 2 steps' },
      { input: 'n = 3', output: '3', explanation: '1. 1 step + 1 step + 1 step\n2. 1 step + 2 steps\n3. 2 steps + 1 step' }
    ],
    constraints: ['1 <= n <= 45'],
    testCases: [
      { input: '2', expectedOutput: '2' },
      { input: '3', expectedOutput: '3' },
      { input: '5', expectedOutput: '8', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def climbStairs(n):
    pass

n = int(input())
print(climbStairs(n))`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 15,
    title: 'First Bad Version',
    difficulty: 'Easy',
    description: `You are a product manager and currently leading a team to develop a new product. Since each version is developed based on the previous version, all the versions after a bad version are also bad. Suppose you have n versions [1, 2, ..., n] and you want to find out the first bad one.`,
    examples: [
      { input: 'n = 5, bad = 4', output: '4' },
      { input: 'n = 1, bad = 1', output: '1' }
    ],
    constraints: ['1 <= bad <= n <= 2^31 - 1'],
    testCases: [
      { input: '5 4', expectedOutput: '4' },
      { input: '1 1', expectedOutput: '1', isHidden: true }
    ],
    codeTemplates: [
      {
        languageId: 71,
        languageName: 'Python',
        starterCode: `def firstBadVersion(n, bad):
    # Simulate isBadVersion API
    def isBadVersion(version):
        return version >= bad
    
    # Your code here
    pass

line = input().split()
n, bad = int(line[0]), int(line[1])
print(firstBadVersion(n, bad))`
      }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 16,
    title: 'Reverse Integer',
    difficulty: 'Medium',
    description: `Given a signed 32-bit integer x, return x with its digits reversed. If reversing x causes the value to go outside the signed 32-bit integer range [-2^31, 2^31 - 1], then return 0.`,
    examples: [
      { input: 'x = 123', output: '321' },
      { input: 'x = -123', output: '-321' },
      { input: 'x = 120', output: '21' }
    ],
    constraints: ['-2^31 <= x <= 2^31 - 1'],
    testCases: [
      { input: '123', expectedOutput: '321' },
      { input: '-123', expectedOutput: '-321' },
      { input: '120', expectedOutput: '21', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def reverse(x):\n    pass\n\nx = int(input())\nprint(reverse(x))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 17,
    title: 'Happy Number',
    difficulty: 'Easy',
    description: `Write an algorithm to determine if a number n is happy. A happy number is a number defined by the following process: Starting with any positive integer, replace the number by the sum of the squares of its digits. Repeat the process until the number equals 1 (where it will stay), or it loops endlessly in a cycle which does not include 1.`,
    examples: [
      { input: 'n = 19', output: 'true' },
      { input: 'n = 2', output: 'false' }
    ],
    constraints: ['1 <= n <= 2^31 - 1'],
    testCases: [
      { input: '19', expectedOutput: 'true' },
      { input: '2', expectedOutput: 'false', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def isHappy(n):\n    pass\n\nn = int(input())\nprint(str(isHappy(n)).lower())` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 18,
    title: 'Intersection of Two Arrays',
    difficulty: 'Easy',
    description: `Given two integer arrays nums1 and nums2, return an array of their intersection. Each element in the result must be unique and you may return the result in any order.`,
    examples: [
      { input: 'nums1 = [1,2,2,1], nums2 = [2,2]', output: '[2]' },
      { input: 'nums1 = [4,9,5], nums2 = [9,4,9,8,4]', output: '[9,4]' }
    ],
    constraints: ['1 <= nums1.length, nums2.length <= 1000'],
    testCases: [
      { input: '1 2 2 1\n2 2', expectedOutput: '2' },
      { input: '4 9 5\n9 4 9 8 4', expectedOutput: '4 9', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def intersection(nums1, nums2):\n    pass\n\nnums1 = list(map(int, input().split()))\nnums2 = list(map(int, input().split()))\nresult = intersection(nums1, nums2)\nprint(' '.join(map(str, sorted(result))))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 19,
    title: 'Remove Duplicates from Sorted Array',
    difficulty: 'Easy',
    description: `Given an integer array nums sorted in non-decreasing order, remove the duplicates in-place such that each unique element appears only once. Return the number of unique elements.`,
    examples: [
      { input: 'nums = [1,1,2]', output: '2' },
      { input: 'nums = [0,0,1,1,1,2,2,3,3,4]', output: '5' }
    ],
    constraints: ['1 <= nums.length <= 3 * 10^4'],
    testCases: [
      { input: '1 1 2', expectedOutput: '2' },
      { input: '0 0 1 1 1 2 2 3 3 4', expectedOutput: '5', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def removeDuplicates(nums):\n    pass\n\nnums = list(map(int, input().split()))\nprint(removeDuplicates(nums))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 20,
    title: 'Plus One',
    difficulty: 'Easy',
    description: `You are given a large integer represented as an integer array digits, where each digits[i] is the ith digit of the integer. Increment the large integer by one and return the resulting array of digits.`,
    examples: [
      { input: 'digits = [1,2,3]', output: '[1,2,4]' },
      { input: 'digits = [9]', output: '[1,0]' }
    ],
    constraints: ['1 <= digits.length <= 100'],
    testCases: [
      { input: '1 2 3', expectedOutput: '1 2 4' },
      { input: '9', expectedOutput: '1 0', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def plusOne(digits):\n    pass\n\ndigits = list(map(int, input().split()))\nresult = plusOne(digits)\nprint(' '.join(map(str, result)))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 21,
    title: 'Valid Anagram',
    difficulty: 'Easy',
    description: `Given two strings s and t, return true if t is an anagram of s, and false otherwise.`,
    examples: [
      { input: 's = "anagram", t = "nagaram"', output: 'true' },
      { input: 's = "rat", t = "car"', output: 'false' }
    ],
    constraints: ['1 <= s.length, t.length <= 5 * 10^4'],
    testCases: [
      { input: 'anagram\nnagaram', expectedOutput: 'true' },
      { input: 'rat\ncar', expectedOutput: 'false', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def isAnagram(s, t):\n    pass\n\ns = input().strip()\nt = input().strip()\nprint(str(isAnagram(s, t)).lower())` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 22,
    title: 'Majority Element',
    difficulty: 'Easy',
    description: `Given an array nums of size n, return the majority element. The majority element is the element that appears more than ⌊n / 2⌋ times.`,
    examples: [
      { input: 'nums = [3,2,3]', output: '3' },
      { input: 'nums = [2,2,1,1,1,2,2]', output: '2' }
    ],
    constraints: ['n == nums.length', '1 <= n <= 5 * 10^4'],
    testCases: [
      { input: '3 2 3', expectedOutput: '3' },
      { input: '2 2 1 1 1 2 2', expectedOutput: '2', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def majorityElement(nums):\n    pass\n\nnums = list(map(int, input().split()))\nprint(majorityElement(nums))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 23,
    title: 'Sqrt(x)',
    difficulty: 'Easy',
    description: `Given a non-negative integer x, return the square root of x rounded down to the nearest integer.`,
    examples: [
      { input: 'x = 4', output: '2' },
      { input: 'x = 8', output: '2' }
    ],
    constraints: ['0 <= x <= 2^31 - 1'],
    testCases: [
      { input: '4', expectedOutput: '2' },
      { input: '8', expectedOutput: '2', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def mySqrt(x):\n    pass\n\nx = int(input())\nprint(mySqrt(x))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 24,
    title: 'Valid Perfect Square',
    difficulty: 'Easy',
    description: `Given a positive integer num, return true if num is a perfect square or false otherwise.`,
    examples: [
      { input: 'num = 16', output: 'true' },
      { input: 'num = 14', output: 'false' }
    ],
    constraints: ['1 <= num <= 2^31 - 1'],
    testCases: [
      { input: '16', expectedOutput: 'true' },
      { input: '14', expectedOutput: 'false', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def isPerfectSquare(num):\n    pass\n\nnum = int(input())\nprint(str(isPerfectSquare(num)).lower())` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 25,
    title: 'Rotate Array',
    difficulty: 'Medium',
    description: `Given an integer array nums, rotate the array to the right by k steps, where k is non-negative.`,
    examples: [
      { input: 'nums = [1,2,3,4,5,6,7], k = 3', output: '[5,6,7,1,2,3,4]' },
      { input: 'nums = [-1,-100,3,99], k = 2', output: '[3,99,-1,-100]' }
    ],
    constraints: ['1 <= nums.length <= 10^5', 'k >= 0'],
    testCases: [
      { input: '1 2 3 4 5 6 7\n3', expectedOutput: '5 6 7 1 2 3 4' },
      { input: '-1 -100 3 99\n2', expectedOutput: '3 99 -1 -100', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def rotate(nums, k):\n    pass\n    return nums\n\nnums = list(map(int, input().split()))\nk = int(input())\nresult = rotate(nums, k)\nprint(' '.join(map(str, result)))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 26,
    title: 'Reverse Bits',
    difficulty: 'Easy',
    description: `Reverse bits of a given 32 bits unsigned integer.`,
    examples: [
      { input: 'n = 43261596', output: '964176192' }
    ],
    constraints: ['The input must be a binary string of length 32'],
    testCases: [
      { input: '43261596', expectedOutput: '964176192' },
      { input: '4294967293', expectedOutput: '3221225471', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def reverseBits(n):\n    pass\n\nn = int(input())\nprint(reverseBits(n))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 27,
    title: 'Number of 1 Bits',
    difficulty: 'Easy',
    description: `Write a function that takes an unsigned integer and returns the number of '1' bits it has (also known as the Hamming weight).`,
    examples: [
      { input: 'n = 11', output: '3' },
      { input: 'n = 128', output: '1' }
    ],
    constraints: ['The input must be a binary string of length 32'],
    testCases: [
      { input: '11', expectedOutput: '3' },
      { input: '128', expectedOutput: '1', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def hammingWeight(n):\n    pass\n\nn = int(input())\nprint(hammingWeight(n))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 28,
    title: 'Pascal\'s Triangle',
    difficulty: 'Easy',
    description: `Given an integer numRows, return the first numRows of Pascal's triangle.`,
    examples: [
      { input: 'numRows = 5', output: '[[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]' }
    ],
    constraints: ['1 <= numRows <= 30'],
    testCases: [
      { input: '5', expectedOutput: '1\n1 1\n1 2 1\n1 3 3 1\n1 4 6 4 1' },
      { input: '1', expectedOutput: '1', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def generate(numRows):\n    pass\n\nnumRows = int(input())\nresult = generate(numRows)\nfor row in result:\n    print(' '.join(map(str, row)))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 29,
    title: 'Convert Sorted Array to Binary Search Tree',
    difficulty: 'Easy',
    description: `Given an integer array nums where the elements are sorted in ascending order, convert it to a height-balanced binary search tree.`,
    examples: [
      { input: 'nums = [-10,-3,0,5,9]', output: '[0,-3,9,-10,null,5]' }
    ],
    constraints: ['1 <= nums.length <= 10^4'],
    testCases: [
      { input: '-10 -3 0 5 9', expectedOutput: '0 -3 9 -10 5' },
      { input: '1 3', expectedOutput: '1 3', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `def sortedArrayToBST(nums):\n    # Return inorder traversal of BST\n    pass\n\nnums = list(map(int, input().split()))\nresult = sortedArrayToBST(nums)\nprint(' '.join(map(str, result)))` }
    ],
    timeLimit: 1,
    memoryLimit: 128
  },
  {
    id: 30,
    title: 'Min Stack',
    difficulty: 'Medium',
    description: `Design a stack that supports push, pop, top, and retrieving the minimum element in constant time.`,
    examples: [
      { input: 'push(-2), push(0), push(-3), getMin(), pop(), top(), getMin()', output: '-3, 0, -2' }
    ],
    constraints: ['-2^31 <= val <= 2^31 - 1'],
    testCases: [
      { input: 'push -2\npush 0\npush -3\ngetMin', expectedOutput: '-3' },
      { input: 'push 1\npush 2\ntop', expectedOutput: '2', isHidden: true }
    ],
    codeTemplates: [
      { languageId: 71, languageName: 'Python', starterCode: `class MinStack:\n    def __init__(self):\n        pass\n    \n    def push(self, val):\n        pass\n    \n    def pop(self):\n        pass\n    \n    def top(self):\n        pass\n    \n    def getMin(self):\n        pass\n\nstack = MinStack()\nwhile True:\n    try:\n        line = input().strip().split()\n        if line[0] == 'push':\n            stack.push(int(line[1]))\n        elif line[0] == 'pop':\n            stack.pop()\n        elif line[0] == 'top':\n            print(stack.top())\n        elif line[0] == 'getMin':\n            print(stack.getMin())\n    except:\n        break` }
    ],
    timeLimit: 2,
    memoryLimit: 256
  }
]

export function getRandomProblem(): Problem {
  const randomIndex = Math.floor(Math.random() * PROBLEMS.length)
  return PROBLEMS[randomIndex]
}

export function getProblemById(id: number): Problem | undefined {
  return PROBLEMS.find(p => p.id === id)
}
