# Backend Rebuild Instructions

## New Features Added
- Code execution endpoints (`/api/execute` and `/api/submit`)
- Theme selector for code editor
- Enhanced output formatting

## Quick Rebuild Options

### Option 1: Using Your IDE (Easiest)
1. Open the backend project in your IDE (IntelliJ IDEA, Eclipse, VS Code)
2. Clean and rebuild the project
3. Run the application with the `dev` profile

### Option 2: Using Maven (if available)
```bash
cd backend
mvn clean package -DskipTests
java -jar target/codebattle-arena-0.0.1-SNAPSHOT.jar --spring.profiles.active=dev
```

### Option 3: Using Gradle (if configured)
```bash
cd backend
./gradlew clean build
java -jar build/libs/codebattle-arena-0.0.1-SNAPSHOT.jar --spring.profiles.active=dev
```

## What Was Added

### New Files:
```
backend/src/main/java/com/codebattle/arena/execution/
├── CodeExecutionController.java       # REST endpoints
├── CodeExecutionService.java          # Business logic  
└── dto/
    ├── ExecuteRequest.java            # Run code request
    ├── SubmitRequest.java             # Submit code request
    ├── ExecutionResponse.java         # Execution results
    └── SubmissionResponse.java        # Submission results
```

### New Endpoints:
- **POST /api/execute** - Run code against one test case
- **POST /api/submit** - Submit code and run all test cases

## Testing After Rebuild

1. Start backend: `java -jar target/codebattle-arena-0.0.1-SNAPSHOT.jar --spring.profiles.active=dev`
2. Frontend should already be running
3. Go to http://localhost:5173
4. Create/join a room
5. Write code and click "Run Code"
6. You should see formatted output in the console

## Current Mode
The code execution is in **MOCK MODE** - it simulates execution.
To enable real code execution, Judge0 API integration is needed.
