-- Add OAuth provider fields to users table
ALTER TABLE users
    ALTER COLUMN password_hash DROP NOT NULL,
    ADD COLUMN provider VARCHAR(50),
    ADD COLUMN provider_id VARCHAR(255);

-- Set existing users to 'local' provider
UPDATE users SET provider = 'local' WHERE provider IS NULL;

-- Add index for provider_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_provider_id ON users(provider, provider_id);
