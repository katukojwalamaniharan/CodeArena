package com.codebattle.arena.execution.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ExecuteRequest {
    @NotBlank(message = "Code is required")
    private String code;
    
    @NotNull(message = "Language ID is required")
    private Integer languageId;
    
    @NotBlank(message = "Test case is required")
    private String testCase;
}
