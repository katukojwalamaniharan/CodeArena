package com.codebattle.arena.api;

import com.codebattle.arena.user.User;
import com.codebattle.arena.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserController {

    private final UserRepository userRepository;

    /**
     * Get all users (admin endpoint)
     * Returns: list of users with basic info
     */
    @GetMapping("/list")
    public ResponseEntity<List<Map<String, Object>>> getAllUsers() {
        List<User> users = userRepository.findAll();
        
        List<Map<String, Object>> userList = users.stream()
            .map(user -> {
                Map<String, Object> userMap = new HashMap<>();
                userMap.put("id", user.getId());
                userMap.put("email", user.getEmail());
                userMap.put("displayName", user.getDisplayName());
                userMap.put("provider", user.getProvider());
                userMap.put("rating", user.getRating());
                userMap.put("wins", user.getWins());
                userMap.put("losses", user.getLosses());
                userMap.put("createdAt", user.getCreatedAt());
                return userMap;
            })
            .collect(Collectors.toList());
        
        return ResponseEntity.ok(userList);
    }

    /**
     * Get user count
     */
    @GetMapping("/count")
    public ResponseEntity<Map<String, Object>> getUserCount() {
        long total = userRepository.count();
        long googleUsers = userRepository.findAll().stream()
            .filter(u -> "google".equals(u.getProvider()))
            .count();
        long localUsers = total - googleUsers;
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", total);
        stats.put("googleUsers", googleUsers);
        stats.put("localUsers", localUsers);
        
        return ResponseEntity.ok(stats);
    }
}
