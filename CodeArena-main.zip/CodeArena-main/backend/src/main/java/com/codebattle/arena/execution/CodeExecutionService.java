package com.codebattle.arena.execution;

import com.codebattle.arena.execution.dto.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CodeExecutionService {

    @Value("${judge0.url:https://judge0-ce.p.rapidapi.com}")
    private String judge0Url;
    
    @Value("${judge0.key:}")
    private String judge0ApiKey;
    
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    /**
     * Execute code against a single test case using Judge0 API
     */
    public ExecutionResponse executeCode(ExecuteRequest request) {
        log.info("Executing code for language ID: {} via Judge0", request.getLanguageId());
        
        try {
            // If Judge0 API key is not configured, use simulation
            if (judge0ApiKey == null || judge0ApiKey.isEmpty()) {
                log.warn("Judge0 API key not configured, using simulation");
                return simulateExecution(request);
            }
            
            // Submit code to Judge0
            String submissionToken = submitToJudge0(
                request.getCode(),
                request.getLanguageId(),
                request.getTestCase()
            );
            
            // Wait and get result
            JsonNode result = getSubmissionResult(submissionToken);
            
            return parseJudge0Response(result);
            
        } catch (Exception e) {
            log.error("Error executing code via Judge0", e);
            // Fallback to simulation on error
            return simulateExecution(request);
        }
    }
    
    /**
     * Submit code to Judge0 API
     */
    private String submitToJudge0(String code, Integer languageId, String stdin) throws Exception {
        String url = judge0Url + "/submissions?base64_encoded=true&wait=false";
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-RapidAPI-Key", judge0ApiKey);
        headers.set("X-RapidAPI-Host", "judge0-ce.p.rapidapi.com");
        
        // Encode code and input in base64
        String encodedCode = Base64.getEncoder().encodeToString(code.getBytes());
        String encodedStdin = Base64.getEncoder().encodeToString(stdin.getBytes());
        
        String requestBody = String.format(
            "{\"language_id\":%d,\"source_code\":\"%s\",\"stdin\":\"%s\"}",
            languageId, encodedCode, encodedStdin
        );
        
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        
        JsonNode jsonResponse = objectMapper.readTree(response.getBody());
        return jsonResponse.get("token").asText();
    }
    
    /**
     * Get submission result from Judge0
     */
    private JsonNode getSubmissionResult(String token) throws Exception {
        String url = judge0Url + "/submissions/" + token + "?base64_encoded=true";
        
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-RapidAPI-Key", judge0ApiKey);
        headers.set("X-RapidAPI-Host", "judge0-ce.p.rapidapi.com");
        
        HttpEntity<String> entity = new HttpEntity<>(headers);
        
        // Poll for result (max 10 times with 1 second intervals)
        for (int i = 0; i < 10; i++) {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            JsonNode result = objectMapper.readTree(response.getBody());
            
            JsonNode status = result.get("status");
            int statusId = status.get("id").asInt();
            
            // Status 1 or 2 means still processing
            if (statusId > 2) {
                return result;
            }
            
            Thread.sleep(1000); // Wait 1 second before next poll
        }
        
        throw new Exception("Execution timeout");
    }
    
    /**
     * Parse Judge0 response
     */
    private ExecutionResponse parseJudge0Response(JsonNode result) {
        try {
            JsonNode status = result.get("status");
            int statusId = status.get("id").asInt();
            String statusDescription = status.get("description").asText();
            
            // Decode output
            String output = "";
            if (result.has("stdout") && !result.get("stdout").isNull()) {
                output = new String(Base64.getDecoder().decode(result.get("stdout").asText()));
            }
            
            String error = "";
            if (result.has("stderr") && !result.get("stderr").isNull()) {
                error = new String(Base64.getDecoder().decode(result.get("stderr").asText()));
            }
            
            if (result.has("compile_output") && !result.get("compile_output").isNull()) {
                String compileError = new String(Base64.getDecoder().decode(result.get("compile_output").asText()));
                if (!compileError.isEmpty()) {
                    error = compileError;
                }
            }
            
            Double time = result.has("time") && !result.get("time").isNull() 
                ? result.get("time").asDouble() : 0.0;
            Integer memory = result.has("memory") && !result.get("memory").isNull() 
                ? result.get("memory").asInt() : 0;
            
            String statusText = statusId == 3 ? "Accepted" : statusDescription;
            
            return ExecutionResponse.builder()
                    .output(output)
                    .status(statusText)
                    .statusDescription(statusDescription)
                    .time(time)
                    .memory(memory)
                    .error(error.isEmpty() ? null : error)
                    .build();
                    
        } catch (Exception e) {
            log.error("Error parsing Judge0 response", e);
            return ExecutionResponse.builder()
                    .output("")
                    .status("Error")
                    .error("Failed to parse execution result")
                    .build();
        }
    }
    
    /**
     * Simulate execution when Judge0 is not available
     */
    private ExecutionResponse simulateExecution(ExecuteRequest request) {
        return ExecutionResponse.builder()
                .output(simulateExecutionOutput(request.getCode(), request.getTestCase()))
                .status("Accepted")
                .statusDescription("Simulated execution (Judge0 not configured)")
                .time(0.05)
                .memory(2048)
                .build();
    }

    /**
     * Submit code and run against all test cases
     * TODO: Integrate with actual problem test cases from database
     */
    public SubmissionResponse submitCode(SubmitRequest request) {
        log.info("Submitting code for problem ID: {}, language ID: {}", 
                request.getProblemId(), request.getLanguageId());
        
        try {
            // Mock submission - Replace with actual test case validation
            List<SubmissionResponse.TestResult> results = new ArrayList<>();
            
            // Simulate 3 test cases
            for (int i = 0; i < 3; i++) {
                results.add(SubmissionResponse.TestResult.builder()
                        .passed(i < 2) // First 2 pass, last one fails (simulation)
                        .input("Test case " + (i + 1))
                        .expectedOutput("Expected output " + (i + 1))
                        .actualOutput(i < 2 ? "Expected output " + (i + 1) : "Wrong output")
                        .build());
            }
            
            long passed = results.stream().filter(SubmissionResponse.TestResult::isPassed).count();
            
            return SubmissionResponse.builder()
                    .status(passed == results.size() ? "Accepted" : "Wrong Answer")
                    .testsPassed((int) passed)
                    .testsTotal(results.size())
                    .details(results)
                    .build();
                    
        } catch (Exception e) {
            log.error("Error submitting code", e);
            return SubmissionResponse.builder()
                    .status("Error")
                    .testsPassed(0)
                    .testsTotal(0)
                    .details(List.of(SubmissionResponse.TestResult.builder()
                            .passed(false)
                            .error(e.getMessage())
                            .build()))
                    .build();
        }
    }

    /**
     * Simulate code execution output
     */
    private String simulateExecutionOutput(String code, String testCase) {
        if (code.toLowerCase().contains("print") || code.toLowerCase().contains("system.out")) {
            return "Code executed successfully!\nMock output for test case: " + testCase + 
                   "\n\n⚠️ Note: This is a simulated execution. Configure Judge0 API for real code execution.";
        }
        return "Code compiled and ran successfully (Mock mode)\nTest input: " + testCase;
    }
}
