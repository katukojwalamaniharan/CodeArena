package com.codebattle.arena.auth;

import com.codebattle.arena.auth.dto.AuthResponse;
import com.codebattle.arena.auth.dto.GoogleLoginRequest;
import com.codebattle.arena.auth.dto.LoginRequest;
import com.codebattle.arena.auth.dto.RegisterRequest;
import com.codebattle.arena.user.User;
import com.codebattle.arena.user.UserRepository;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Collections;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Value("${google.client.id:}")
    private String googleClientId;

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new IllegalArgumentException("Email already registered");
        }
        User user = User.builder()
                .email(req.getEmail().toLowerCase())
                .displayName(req.getDisplayName())
                .passwordHash(passwordEncoder.encode(req.getPassword()))
                .provider("local")
                .rating(1200)
                .wins(0)
                .losses(0)
                .createdAt(Instant.now())
                .build();
        user = userRepository.save(user);
        String token = jwtService.generateToken(user);
        return new AuthResponse(token, user.getId(), user.getDisplayName(), user.getEmail());
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest req) {
        User user = userRepository.findByEmail(req.getEmail().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
        if (!passwordEncoder.matches(req.getPassword(), user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid credentials");
        }
        String token = jwtService.generateToken(user);
        return new AuthResponse(token, user.getId(), user.getDisplayName(), user.getEmail());
    }

    @Transactional
    public AuthResponse googleLogin(GoogleLoginRequest req) {
        try {
            // Verify the Google ID token
            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
                    new NetHttpTransport(), new GsonFactory())
                    .setAudience(Collections.singletonList(googleClientId))
                    .build();

            GoogleIdToken idToken = verifier.verify(req.getIdToken());
            if (idToken == null) {
                throw new IllegalArgumentException("Invalid Google ID token");
            }

            GoogleIdToken.Payload payload = idToken.getPayload();
            String email = payload.getEmail();
            String googleId = payload.getSubject();
            String displayName = (String) payload.get("name");

            // Check if user exists by email or provider ID
            User user = userRepository.findByEmail(email.toLowerCase()).orElse(null);

            if (user == null) {
                // Create new user with Google OAuth
                user = User.builder()
                        .email(email.toLowerCase())
                        .displayName(displayName != null ? displayName : email.split("@")[0])
                        .provider("google")
                        .providerId(googleId)
                        .rating(1200)
                        .wins(0)
                        .losses(0)
                        .createdAt(Instant.now())
                        .build();
                user = userRepository.save(user);
            } else if (user.getProvider() == null || "local".equals(user.getProvider())) {
                // Link existing local account with Google
                user.setProvider("google");
                user.setProviderId(googleId);
                user = userRepository.save(user);
            }

            String token = jwtService.generateToken(user);
            return new AuthResponse(token, user.getId(), user.getDisplayName(), user.getEmail());

        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to authenticate with Google: " + e.getMessage());
        }
    }
}
