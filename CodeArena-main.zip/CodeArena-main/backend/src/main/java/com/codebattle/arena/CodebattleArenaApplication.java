package com.codebattle.arena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodebattleArenaApplication {
    public static void main(String[] args) {
        SpringApplication.run(CodebattleArenaApplication.class, args);
    }
}
