package com.codebattle.arena.admin;

import com.codebattle.arena.auth.dto.AuthResponse;
import com.codebattle.arena.auth.dto.LoginRequest;
import com.codebattle.arena.auth.JwtService;
import com.codebattle.arena.user.User;
import com.codebattle.arena.user.UserRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AdminController {

    private final UserRepository userRepository;
    private final JwtService jwtService;

    @Value("${admin.email:krupakargurija177@gmail.com}")
    private String adminEmail;

    @Value("${admin.password:nobita@2004}")
    private String adminPassword;

    /**
     * Admin login endpoint
     */
    @PostMapping("/login")
    public ResponseEntity<?> adminLogin(@Valid @RequestBody LoginRequest req) {
        // Check if credentials match admin
        if (!adminEmail.equalsIgnoreCase(req.getEmail())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid admin credentials"));
        }

        if (!adminPassword.equals(req.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid admin credentials"));
        }

        // Create admin user object for token
        User adminUser = User.builder()
            .id(0L)
            .email(adminEmail)
            .displayName("Admin")
            .build();

        String token = jwtService.generateToken(adminUser);

        return ResponseEntity.ok(new AuthResponse(
            token,
            0L,
            "Admin",
            adminEmail
        ));
    }

    /**
     * Verify if user is admin
     */
    @PostMapping("/verify")
    public ResponseEntity<?> verifyAdmin(@RequestHeader("Authorization") String authHeader) {
        try {
            String token = authHeader.substring(7); // Remove "Bearer "
            String email = jwtService.extractEmail(token);
            
            if (adminEmail.equalsIgnoreCase(email)) {
                return ResponseEntity.ok(Map.of("isAdmin", true));
            }
            
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(Map.of("isAdmin", false, "error", "Not an admin"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));
        }
    }

    /**
     * Get all users (admin only)
     */
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        try {
            // Check if Authorization header exists
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Authorization header required"));
            }

            String token = authHeader.substring(7);
            String email = jwtService.extractEmail(token);

            System.out.println("DEBUG: Admin check - Token email: " + email + ", Config admin email: " + adminEmail);

            if (!adminEmail.equalsIgnoreCase(email)) {
                System.out.println("DEBUG: Admin access denied - Email mismatch");
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Admin access required"));
            }

            List<User> users = userRepository.findAll();

            List<Map<String, Object>> userList = users.stream()
                .map(user -> {
                    Map<String, Object> userMap = new HashMap<>();
                    userMap.put("id", user.getId());
                    userMap.put("email", user.getEmail());
                    userMap.put("displayName", user.getDisplayName());
                    userMap.put("provider", user.getProvider());
                    userMap.put("rating", user.getRating());
                    userMap.put("wins", user.getWins());
                    userMap.put("losses", user.getLosses());
                    userMap.put("createdAt", user.getCreatedAt());
                    return userMap;
                })
                .collect(Collectors.toList());

            System.out.println("DEBUG: Admin access granted - Found " + users.size() + " users");
            return ResponseEntity.ok(userList);
        } catch (Exception e) {
            System.err.println("DEBUG: Admin users error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));
        }
    }

    /**
     * Get dashboard statistics (admin only)
     */
    @GetMapping("/stats")
    public ResponseEntity<?> getStats(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        try {
            // Check if Authorization header exists
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Authorization header required"));
            }

            String token = authHeader.substring(7);
            String email = jwtService.extractEmail(token);

            System.out.println("DEBUG: Stats check - Token email: " + email + ", Config admin email: " + adminEmail);

            if (!adminEmail.equalsIgnoreCase(email)) {
                System.out.println("DEBUG: Stats access denied - Email mismatch");
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Admin access required"));
            }

            List<User> users = userRepository.findAll();

            long totalUsers = users.size();
            long googleUsers = users.stream()
                .filter(u -> "google".equals(u.getProvider()))
                .count();
            long localUsers = users.stream()
                .filter(u -> "local".equals(u.getProvider()))
                .count();

            double avgRating = users.stream()
                .mapToInt(User::getRating)
                .average()
                .orElse(0);

            Map<String, Object> stats = new HashMap<>();
            stats.put("totalUsers", totalUsers);
            stats.put("googleUsers", googleUsers);
            stats.put("localUsers", localUsers);
            stats.put("averageRating", Math.round(avgRating));

            System.out.println("DEBUG: Stats access granted - Total users: " + totalUsers);
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            System.err.println("DEBUG: Admin stats error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid token"));
        }
    }
}
