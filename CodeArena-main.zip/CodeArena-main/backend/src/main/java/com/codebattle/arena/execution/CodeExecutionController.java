package com.codebattle.arena.execution;

import com.codebattle.arena.execution.dto.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class CodeExecutionController {

    private final CodeExecutionService codeExecutionService;

    @PostMapping("/execute")
    public ResponseEntity<ExecutionResponse> executeCode(@Valid @RequestBody ExecuteRequest request) {
        ExecutionResponse response = codeExecutionService.executeCode(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/submit")
    public ResponseEntity<SubmissionResponse> submitCode(@Valid @RequestBody SubmitRequest request) {
        SubmissionResponse response = codeExecutionService.submitCode(request);
        return ResponseEntity.ok(response);
    }
}
